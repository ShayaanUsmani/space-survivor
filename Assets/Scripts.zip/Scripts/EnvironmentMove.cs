﻿using UnityEngine;

// Makes the environment asset move forward as the player moves forward
public class EnvironmentMove : GameMethods
{
    private Rigidbody rb; //rigid body of the gameobject this script is attached to

    private Rigidbody playerRB; //rigidbody of the player
    private string playerTag = "Player";

    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();
        playerRB = GameObject.FindGameObjectWithTag(playerTag).GetComponent<Rigidbody>(); //find a gameobject in hierarchy
                                                                                          //with the player tag and get its
                                                                                          //rigidbody component which is
                                                                                          //the playerRB
    }

    void FixedUpdate()
    {
        rb.velocity = Vector3.forward * playerRB.velocity.z; //set velocity of the gameObject to the velocity in the z
                                                             //direction of the player
    }
}
